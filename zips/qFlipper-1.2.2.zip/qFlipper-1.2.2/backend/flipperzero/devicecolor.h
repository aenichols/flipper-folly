#pragma once

namespace Flipper {
namespace Zero {

enum class Color {
    Unknown = 0,
    Black,
    White
};

}
}

