#pragma once

namespace Flipper {
namespace Zero {

enum class Region {
    Dev = 0x00,
    EuRu,
    USCaAu,
    JpPlus,
    Worldwide
};

}
}
