#pragma once

#include <QString>

namespace STM32 {
namespace WB55 {

struct VersionInfo
{
    QString FUSVersion;
    QString WirelessVersion;
};

}}
