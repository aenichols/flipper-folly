# Contributed packages
This directory contains community-contributed files for various package management systems. None of them were tested by Flipper QA.

For each system, see the respective subdirectory.
